const eventsource = new EventSource('http://localhost:4000/graphql');
console.log(eventsource);